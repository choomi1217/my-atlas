package com.myqaweb.monitoring;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Unit tests for MonitoringController — Platform v11 Step 4.
 *
 * <p>The controller mapping moved from {@code /api/admin/monitoring} → {@code /api/monitoring}
 * so demo-mode anonymous users can see usage data without acquiring ADMIN role.
 * Authentication is enforced by SecurityConfig (not the controller), so these tests
 * use standalone MockMvc and only verify routing + response shape.
 */
@ExtendWith(MockitoExtension.class)
class MonitoringControllerTest {

    @Mock
    private MonitoringService monitoringService;

    @InjectMocks
    private MonitoringController monitoringController;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    void initMockMvc() {
        mockMvc = MockMvcBuilders.standaloneSetup(monitoringController).build();
    }

    // --- Path verification ---

    @Test
    void getAiSummary_routesUnderApiMonitoring() throws Exception {
        initMockMvc();
        when(monitoringService.getAiUsageSummary(any(), any()))
                .thenReturn(emptyAiUsageSummary());

        mockMvc.perform(get("/api/monitoring/ai-summary")
                        .param("from", "2026-04-01")
                        .param("to", "2026-04-28")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data").exists());
    }

    @Test
    void getAiSummary_oldAdminPath_returnsNotFound() throws Exception {
        initMockMvc();
        // Old path /api/admin/monitoring/* must NOT be routed any more —
        // we want clients to break loud rather than silently work both ways.
        mockMvc.perform(get("/api/admin/monitoring/ai-summary")
                        .param("from", "2026-04-01")
                        .param("to", "2026-04-28"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getDailyTrend_routesUnderApiMonitoring() throws Exception {
        initMockMvc();
        when(monitoringService.getDailyTrend(any(), any()))
                .thenReturn(List.of());

        mockMvc.perform(get("/api/monitoring/ai-daily-trend")
                        .param("from", "2026-04-01")
                        .param("to", "2026-04-28"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void getByFeature_routesUnderApiMonitoring() throws Exception {
        initMockMvc();
        when(monitoringService.getAiUsageSummary(any(), any()))
                .thenReturn(emptyAiUsageSummary());

        mockMvc.perform(get("/api/monitoring/ai-by-feature")
                        .param("from", "2026-04-01")
                        .param("to", "2026-04-28"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void getApiSummary_routesUnderApiMonitoring() throws Exception {
        initMockMvc();
        when(monitoringService.getApiAccessSummary(any(), any()))
                .thenReturn(new MonitoringDto.ApiAccessSummary(0L, List.of(), List.of()));

        mockMvc.perform(get("/api/monitoring/api-summary")
                        .param("from", "2026-04-01")
                        .param("to", "2026-04-28"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.totalRequests").value(0));
    }

    // --- Date param wiring ---

    @Test
    void getAiSummary_invalidDateFormat_returnsBadRequest() throws Exception {
        initMockMvc();

        mockMvc.perform(get("/api/monitoring/ai-summary")
                        .param("from", "not-a-date")
                        .param("to", "2026-04-28"))
                .andExpect(status().is4xxClientError());
    }

    @Test
    void getAiSummary_missingFromParam_returnsBadRequest() throws Exception {
        initMockMvc();

        mockMvc.perform(get("/api/monitoring/ai-summary")
                        .param("to", "2026-04-28"))
                .andExpect(status().is4xxClientError());
    }

    @Test
    void getAiSummary_passesEndOfDayToServiceForToParam() throws Exception {
        // The to-date should arrive at the service as 23:59:59.999... so the day is
        // fully inclusive. Mistakes here lead to "today's usage missing" bugs.
        initMockMvc();
        when(monitoringService.getAiUsageSummary(any(), any()))
                .thenReturn(emptyAiUsageSummary());

        mockMvc.perform(get("/api/monitoring/ai-summary")
                        .param("from", "2026-04-28")
                        .param("to", "2026-04-28"))
                .andExpect(status().isOk());

        org.mockito.ArgumentCaptor<java.time.LocalDateTime> fromCap =
                org.mockito.ArgumentCaptor.forClass(java.time.LocalDateTime.class);
        org.mockito.ArgumentCaptor<java.time.LocalDateTime> toCap =
                org.mockito.ArgumentCaptor.forClass(java.time.LocalDateTime.class);
        verify(monitoringService, times(1))
                .getAiUsageSummary(fromCap.capture(), toCap.capture());

        java.time.LocalDateTime fromVal = fromCap.getValue();
        java.time.LocalDateTime toVal = toCap.getValue();
        org.junit.jupiter.api.Assertions.assertEquals(LocalDate.of(2026, 4, 28),
                fromVal.toLocalDate());
        org.junit.jupiter.api.Assertions.assertEquals(0, fromVal.getHour(),
                "from must start at 00:00 — was " + fromVal);
        org.junit.jupiter.api.Assertions.assertEquals(23, toVal.getHour(),
                "to must reach end of day — was " + toVal);
        org.junit.jupiter.api.Assertions.assertEquals(59, toVal.getMinute());
    }

    // --- Response payload routing ---

    @Test
    void getByFeature_returnsByFeatureSliceOfSummary() throws Exception {
        initMockMvc();
        MonitoringDto.FeatureUsage row = new MonitoringDto.FeatureUsage(
                "EMBEDDING_PDF", "OPENAI", 17L, 1000L, 0L,
                new BigDecimal("0.0042"), 12.3);
        MonitoringDto.AiUsageSummary summary = new MonitoringDto.AiUsageSummary(
                17L, 1000L, new BigDecimal("0.0042"), 17L, 0L,
                List.of(), List.of(row));
        when(monitoringService.getAiUsageSummary(any(), any())).thenReturn(summary);

        mockMvc.perform(get("/api/monitoring/ai-by-feature")
                        .param("from", "2026-04-01")
                        .param("to", "2026-04-28"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data[0].feature").value("EMBEDDING_PDF"))
                .andExpect(jsonPath("$.data[0].calls").value(17));
    }

    @Test
    void getDailyTrend_emptyList_succeeds() throws Exception {
        initMockMvc();
        when(monitoringService.getDailyTrend(any(), any())).thenReturn(List.of());

        mockMvc.perform(get("/api/monitoring/ai-daily-trend")
                        .param("from", "2026-04-01")
                        .param("to", "2026-04-02"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data.length()").value(0));
    }

    private MonitoringDto.AiUsageSummary emptyAiUsageSummary() {
        return new MonitoringDto.AiUsageSummary(
                0L, 0L, BigDecimal.ZERO, 0L, 0L, List.of(), List.of());
    }
}
