package com.myqaweb.common;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Unit tests for SlackNotificationService — both per-call ({@code notifyAiUsage})
 * and batched ({@code notifyAiUsageBatch}, Platform v11 Step 2) flows.
 */
@ExtendWith(MockitoExtension.class)
class SlackNotificationServiceTest {

    private static final String WEBHOOK_URL = "https://hooks.slack.com/services/TEST";

    @Mock
    private RestTemplate restTemplate;

    private SlackNotificationService service;

    @BeforeEach
    void setUp() {
        service = new SlackNotificationService(WEBHOOK_URL);
        // Replace the privately-instantiated RestTemplate with a mock so we can verify
        // the outbound HTTP call without performing one.
        ReflectionTestUtils.setField(service, "restTemplate", restTemplate);
    }

    // --- notifyAiUsage (per-call) ---

    @Test
    void notifyAiUsage_postsToWebhook_whenEnabled() {
        service.notifyAiUsage("alice", "KB Embedding", 12_345);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String, String>> bodyCaptor = ArgumentCaptor.forClass(Map.class);
        verify(restTemplate, times(1))
                .postForEntity(eq(WEBHOOK_URL), bodyCaptor.capture(), eq(String.class));

        String text = bodyCaptor.getValue().get("text");
        assertTrue(text.contains("alice"), "username included");
        assertTrue(text.contains("KB Embedding"), "endpoint included");
        assertTrue(text.contains("12,345"), "tokens with thousand separator: " + text);
        assertFalse(text.contains("(Batch)"), "per-call message must not look like batch");
    }

    @Test
    void notifyAiUsage_silentlyTolerantOfWebhookFailure() {
        when(restTemplate.postForEntity(eq(WEBHOOK_URL), any(), eq(String.class)))
                .thenThrow(new ResourceAccessException("connect timeout"));

        // Must not propagate — Slack is best-effort.
        service.notifyAiUsage("bob", "Senior Chat", 100);

        verify(restTemplate).postForEntity(eq(WEBHOOK_URL), any(), eq(String.class));
    }

    @Test
    void notifyAiUsage_disabledWhenWebhookBlank() {
        SlackNotificationService disabled = new SlackNotificationService("");
        ReflectionTestUtils.setField(disabled, "restTemplate", restTemplate);

        disabled.notifyAiUsage("u", "e", 1);

        verifyNoInteractions(restTemplate);
    }

    @Test
    void notifyAiUsage_disabledWhenWebhookNull() {
        SlackNotificationService disabled = new SlackNotificationService(null);
        ReflectionTestUtils.setField(disabled, "restTemplate", restTemplate);

        disabled.notifyAiUsage("u", "e", 1);

        verifyNoInteractions(restTemplate);
    }

    // --- notifyAiUsageBatch (Platform v11 Step 2) ---

    @Test
    void notifyAiUsageBatch_postsSingleMessage_withAllFields() {
        BigDecimal cost = new BigDecimal("0.0042");
        service.notifyAiUsageBatch("alice", "PDF Embedding (book='QA Handbook')",
                17, 4_321L, cost);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String, String>> bodyCaptor = ArgumentCaptor.forClass(Map.class);
        verify(restTemplate, times(1))
                .postForEntity(eq(WEBHOOK_URL), bodyCaptor.capture(), eq(String.class));

        String text = bodyCaptor.getValue().get("text");
        assertTrue(text.contains("(Batch)"), "should be labelled as batch: " + text);
        assertTrue(text.contains("alice"), "username included");
        assertTrue(text.contains("QA Handbook"), "endpoint label included");
        assertTrue(text.contains("Calls: 17"), "callCount included literally");
        assertTrue(text.contains("4,321"), "totalTokens with thousand separator");
        assertTrue(text.contains("0.0042"), "cost included with 4 decimals: " + text);
    }

    @Test
    void notifyAiUsageBatch_omitsCostLine_whenNull() {
        service.notifyAiUsageBatch("alice", "PDF Embedding", 5, 100L, null);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String, String>> bodyCaptor = ArgumentCaptor.forClass(Map.class);
        verify(restTemplate).postForEntity(eq(WEBHOOK_URL), bodyCaptor.capture(), eq(String.class));

        String text = bodyCaptor.getValue().get("text");
        assertFalse(text.contains("Estimated Cost"),
                "Cost line should be omitted when cost is null: " + text);
        assertTrue(text.contains("Calls: 5"));
    }

    @Test
    void notifyAiUsageBatch_noOpWhenCallCountZero() {
        // Worker invokes this in a finally block — must be safe for "nothing happened" jobs.
        service.notifyAiUsageBatch("alice", "PDF Embedding", 0, 0L, BigDecimal.ZERO);

        verifyNoInteractions(restTemplate);
    }

    @Test
    void notifyAiUsageBatch_noOpWhenCallCountNegative() {
        service.notifyAiUsageBatch("alice", "PDF Embedding", -1, 0L, null);

        verifyNoInteractions(restTemplate);
    }

    @Test
    void notifyAiUsageBatch_disabledWhenWebhookBlank() {
        SlackNotificationService disabled = new SlackNotificationService("");
        ReflectionTestUtils.setField(disabled, "restTemplate", restTemplate);

        disabled.notifyAiUsageBatch("alice", "PDF", 5, 100L, BigDecimal.ONE);

        verifyNoInteractions(restTemplate);
    }

    @Test
    void notifyAiUsageBatch_silentlyTolerantOfWebhookFailure() {
        when(restTemplate.postForEntity(eq(WEBHOOK_URL), any(), eq(String.class)))
                .thenThrow(new ResourceAccessException("connect timeout"));

        // Must not propagate — Slack is best-effort even for batch.
        service.notifyAiUsageBatch("alice", "PDF", 5, 100L, BigDecimal.ONE);

        verify(restTemplate).postForEntity(eq(WEBHOOK_URL), any(), eq(String.class));
    }

    @Test
    void notifyAiUsageBatch_costRoundedToFourDecimals() {
        BigDecimal cost = new BigDecimal("0.000123456789");
        service.notifyAiUsageBatch("alice", "PDF", 1, 1L, cost);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String, String>> bodyCaptor = ArgumentCaptor.forClass(Map.class);
        verify(restTemplate).postForEntity(eq(WEBHOOK_URL), bodyCaptor.capture(), eq(String.class));

        String text = bodyCaptor.getValue().get("text");
        assertTrue(text.contains("0.0001"),
                "Cost should be rounded HALF_UP to 4 decimals: " + text);
        assertFalse(text.contains("0.000123456789"),
                "Full precision should not leak into the message: " + text);
    }

    @Test
    void notifyAiUsageBatch_isolatedFromPerCallVerb() {
        // Verifies notifyAiUsage and notifyAiUsageBatch are independent code paths
        // — calling batch must not increment the per-call count and vice versa.
        service.notifyAiUsage("alice", "KB Embedding", 100);
        service.notifyAiUsageBatch("alice", "PDF", 3, 300L, BigDecimal.ZERO);

        verify(restTemplate, times(2))
                .postForEntity(eq(WEBHOOK_URL), any(), eq(String.class));
    }

    @Test
    void notifyAiUsage_doesNotEmitBatchHeader() {
        service.notifyAiUsage("alice", "Senior Chat", 100);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String, String>> bodyCaptor = ArgumentCaptor.forClass(Map.class);
        verify(restTemplate).postForEntity(eq(WEBHOOK_URL), bodyCaptor.capture(), eq(String.class));

        String text = bodyCaptor.getValue().get("text");
        assertFalse(text.contains("Batch"),
                "Per-call message must not include 'Batch' label: " + text);
        assertFalse(text.contains("Calls:"),
                "Per-call message must not show 'Calls:' field: " + text);
    }

    @Test
    void notifyAiUsageBatch_called_whenCallCountIsOne() {
        // Edge case: a "batch" of 1 call still goes through (caller decides scope).
        service.notifyAiUsageBatch("alice", "PDF", 1, 50L, new BigDecimal("0.001"));

        verify(restTemplate, times(1))
                .postForEntity(eq(WEBHOOK_URL), any(), eq(String.class));
    }

    @Test
    void notifyAiUsage_neverInvokesBatchPath() {
        service.notifyAiUsage("alice", "KB Embedding", 100);
        service.notifyAiUsage("alice", "Senior Chat", 200);

        verify(restTemplate, times(2))
                .postForEntity(eq(WEBHOOK_URL), any(), eq(String.class));
        // No assertion about batch state needed — webhook calls counted above.
    }

    @Test
    void notifyAiUsageBatch_neverInvokesPerCallPath() {
        // 3 batch invocations should produce 3 webhook calls — no per-call multiplexing.
        service.notifyAiUsageBatch("u", "e", 5, 100L, BigDecimal.ZERO);
        service.notifyAiUsageBatch("u", "e", 10, 200L, BigDecimal.ZERO);
        service.notifyAiUsageBatch("u", "e", 1, 50L, BigDecimal.ZERO);

        verify(restTemplate, times(3))
                .postForEntity(eq(WEBHOOK_URL), any(), eq(String.class));
    }

    @Test
    void notifyAiUsageBatch_postedTimestampIsFresh() {
        service.notifyAiUsageBatch("alice", "PDF", 1, 1L, null);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String, String>> bodyCaptor = ArgumentCaptor.forClass(Map.class);
        verify(restTemplate).postForEntity(eq(WEBHOOK_URL), bodyCaptor.capture(), eq(String.class));

        String text = bodyCaptor.getValue().get("text");
        // Timestamp format: yyyy-MM-dd HH:mm:ss — verify a 4-digit year is present
        assertTrue(text.matches("(?s).*\\b20\\d{2}-\\d{2}-\\d{2}\\s+\\d{2}:\\d{2}:\\d{2}\\b.*"),
                "Should contain ISO-like timestamp: " + text);
    }
}
