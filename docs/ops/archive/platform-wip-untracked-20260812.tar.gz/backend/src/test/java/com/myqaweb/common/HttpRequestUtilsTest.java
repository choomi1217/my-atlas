package com.myqaweb.common;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

/**
 * Unit tests for HttpRequestUtils — covers both the request-arg variant
 * (used in synchronous controller code) and the RequestContextHolder fallback
 * (used by legacy callers; returns null in {@code @Async} threads).
 */
@ExtendWith(MockitoExtension.class)
class HttpRequestUtilsTest {

    @Mock
    private HttpServletRequest request;

    @AfterEach
    void clearRequestContext() {
        RequestContextHolder.resetRequestAttributes();
    }

    // --- extractClientIp(HttpServletRequest) ---

    @Test
    void extractClientIp_returnsXForwardedFor_singleEntry() {
        when(request.getHeader("X-Forwarded-For")).thenReturn("203.0.113.42");
        // RemoteAddr should be ignored when XFF is present
        lenient().when(request.getRemoteAddr()).thenReturn("10.0.0.1");

        assertEquals("203.0.113.42", HttpRequestUtils.extractClientIp(request));
    }

    @Test
    void extractClientIp_pickFirstIpFromMultiHopXForwardedFor() {
        // ALB chain: client → CloudFront → ALB → app. Only the first IP is the real client.
        when(request.getHeader("X-Forwarded-For"))
                .thenReturn("203.0.113.42, 198.51.100.5, 10.0.0.1");

        assertEquals("203.0.113.42", HttpRequestUtils.extractClientIp(request));
    }

    @Test
    void extractClientIp_trimsWhitespaceAroundFirstIp() {
        when(request.getHeader("X-Forwarded-For"))
                .thenReturn("   203.0.113.42  ,  198.51.100.5");

        assertEquals("203.0.113.42", HttpRequestUtils.extractClientIp(request));
    }

    @Test
    void extractClientIp_fallsBackToRemoteAddr_whenXForwardedForMissing() {
        when(request.getHeader("X-Forwarded-For")).thenReturn(null);
        when(request.getRemoteAddr()).thenReturn("10.0.0.1");

        assertEquals("10.0.0.1", HttpRequestUtils.extractClientIp(request));
    }

    @Test
    void extractClientIp_fallsBackToRemoteAddr_whenXForwardedForBlank() {
        when(request.getHeader("X-Forwarded-For")).thenReturn("   ");
        when(request.getRemoteAddr()).thenReturn("10.0.0.1");

        assertEquals("10.0.0.1", HttpRequestUtils.extractClientIp(request));
    }

    @Test
    void extractClientIp_fallsBackToRemoteAddr_whenXForwardedForEmpty() {
        when(request.getHeader("X-Forwarded-For")).thenReturn("");
        when(request.getRemoteAddr()).thenReturn("10.0.0.1");

        assertEquals("10.0.0.1", HttpRequestUtils.extractClientIp(request));
    }

    @Test
    void extractClientIp_handlesNullRequestGracefully() {
        assertNull(HttpRequestUtils.extractClientIp(null),
                "Null request must yield null IP, not throw");
    }

    @Test
    void extractClientIp_handlesIpv6AddressFromXff() {
        when(request.getHeader("X-Forwarded-For"))
                .thenReturn("2001:db8::1, 2001:db8::2");

        assertEquals("2001:db8::1", HttpRequestUtils.extractClientIp(request));
    }

    @Test
    void extractClientIp_returnsRemoteAddr_evenWhenItself_isLoopback() {
        // No XFF in tests where ALB is bypassed; just trust the raw remote.
        when(request.getHeader("X-Forwarded-For")).thenReturn(null);
        when(request.getRemoteAddr()).thenReturn("127.0.0.1");

        assertEquals("127.0.0.1", HttpRequestUtils.extractClientIp(request));
    }

    // --- extractClientIpFromContext() ---

    @Test
    void extractClientIpFromContext_returnsIpFromBoundContext() {
        MockHttpServletRequest req = new MockHttpServletRequest();
        req.addHeader("X-Forwarded-For", "203.0.113.42, 10.0.0.1");
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(req));

        assertEquals("203.0.113.42", HttpRequestUtils.extractClientIpFromContext());
    }

    @Test
    void extractClientIpFromContext_returnsNull_whenNoBoundContext() {
        // Default state — no thread-local request attributes (e.g. @Async worker)
        RequestContextHolder.resetRequestAttributes();

        assertNull(HttpRequestUtils.extractClientIpFromContext(),
                "Should return null in @Async / no-context path, not throw");
    }

    @Test
    void extractClientIpFromContext_fallsBackToRemoteAddr_inBoundContext() {
        MockHttpServletRequest req = new MockHttpServletRequest();
        req.setRemoteAddr("10.0.0.1");
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(req));

        assertEquals("10.0.0.1", HttpRequestUtils.extractClientIpFromContext());
    }
}
