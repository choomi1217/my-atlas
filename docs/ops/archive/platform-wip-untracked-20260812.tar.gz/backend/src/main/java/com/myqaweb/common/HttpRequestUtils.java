package com.myqaweb.common;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Static helpers for extracting per-request metadata.
 *
 * <p>Two flavours are provided:
 * <ul>
 *   <li>{@link #extractClientIp(HttpServletRequest)} — when the caller has the request
 *       in scope. Use this in synchronous controller code.</li>
 *   <li>{@link #extractClientIpFromContext()} — best-effort IP from
 *       {@link RequestContextHolder}. Returns null when called from an {@code @Async}
 *       thread (no request context). Use only as a fallback.</li>
 * </ul>
 *
 * <p>Both forms honour {@code X-Forwarded-For} for ALB / reverse-proxy environments,
 * picking the leftmost IP (the original client) and falling back to
 * {@code request.getRemoteAddr()} when the header is absent.
 */
public final class HttpRequestUtils {

    private HttpRequestUtils() {
        // utility
    }

    /**
     * Extracts the client IP from the given request.
     * Honours {@code X-Forwarded-For} (leftmost entry) before falling back to
     * {@link HttpServletRequest#getRemoteAddr()}.
     *
     * @return the client IP, or null if {@code request} is null
     */
    public static String extractClientIp(HttpServletRequest request) {
        if (request == null) return null;
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            int comma = forwarded.indexOf(',');
            return (comma > 0 ? forwarded.substring(0, comma) : forwarded).trim();
        }
        return request.getRemoteAddr();
    }

    /**
     * Best-effort variant for synchronous code paths that don't have the request
     * injected. Returns null when invoked from an {@code @Async} thread or outside
     * a request scope.
     */
    public static String extractClientIpFromContext() {
        try {
            ServletRequestAttributes attrs =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attrs == null) return null;
            return extractClientIp(attrs.getRequest());
        } catch (Exception e) {
            return null;
        }
    }
}
