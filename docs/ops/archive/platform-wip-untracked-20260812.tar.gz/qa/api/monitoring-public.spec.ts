import { test, expect, APIRequestContext } from '@playwright/test';

/**
 * Platform v11 Step 4 — Monitoring API public access.
 *
 * Verifies that /api/monitoring/* responds correctly under the three identity
 * states the demo-mode policy targets:
 *   1. ADMIN authenticated (always allowed)
 *   2. USER authenticated (no longer ADMIN-only after Step 4 path move)
 *   3. anonymous + loginRequired=false (demo mode anonymous access)
 *
 * Also asserts response shape so a regression that strips fields (e.g. cost)
 * is caught at the API layer rather than at the chart-render boundary.
 *
 * Restores loginRequired=true in afterAll. Does not touch any other settings.
 */

const API_URL = process.env.API_URL || 'http://localhost:8080';

let adminRequest: APIRequestContext;
let anonRequest: APIRequestContext;
let userRequest: APIRequestContext | null = null;
let originalLoginRequired: boolean = true;
let createdUserId: number | null = null;

const TEST_USER = {
  username: `e2e_monitor_user_${Date.now()}`,
  password: 'E2eMonitor!1234',
  role: 'USER',
};

test.beforeAll(async ({ playwright }) => {
  // Admin login
  const base = await playwright.request.newContext({ baseURL: API_URL });
  const loginResp = await base.post('/api/auth/login', {
    data: { username: 'admin', password: 'admin' },
  });
  expect(loginResp.status()).toBe(200);
  const adminToken = (await loginResp.json() as any).data.token;
  await base.dispose();

  adminRequest = await playwright.request.newContext({
    baseURL: API_URL,
    extraHTTPHeaders: { Authorization: `Bearer ${adminToken}` },
  });
  anonRequest = await playwright.request.newContext({ baseURL: API_URL });

  // Snapshot loginRequired and force demo mode for anonymous tests.
  const settingsResp = await adminRequest.get('/api/settings');
  originalLoginRequired = (await settingsResp.json() as any).data.loginRequired;

  await adminRequest.patch('/api/settings', { data: { loginRequired: false } });

  // Create a non-admin USER and acquire its token (assigned to all companies = no filter)
  // so we can verify USER role can also reach monitoring after the path move.
  const allCompanies = await adminRequest.get('/api/companies');
  const companyIds = ((await allCompanies.json() as any).data as Array<{ id: number }>)
      .map(c => c.id);
  const registerResp = await adminRequest.post('/api/settings/users', {
    data: { ...TEST_USER, companyIds },
  });
  if (registerResp.status() === 201) {
    createdUserId = ((await registerResp.json() as any).data.id) as number;
    const userLogin = await playwright.request.newContext({ baseURL: API_URL });
    const userLoginResp = await userLogin.post('/api/auth/login', {
      data: { username: TEST_USER.username, password: TEST_USER.password },
    });
    if (userLoginResp.status() === 200) {
      const userToken = (await userLoginResp.json() as any).data.token;
      userRequest = await playwright.request.newContext({
        baseURL: API_URL,
        extraHTTPHeaders: { Authorization: `Bearer ${userToken}` },
      });
    }
    await userLogin.dispose();
  }
});

test.afterAll(async () => {
  try {
    if (adminRequest) {
      await adminRequest.patch('/api/settings', { data: { loginRequired: originalLoginRequired } });
      if (createdUserId != null) {
        await adminRequest.delete(`/api/settings/users/${createdUserId}`).catch(() => {});
      }
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('monitoring-public afterAll cleanup failed:', err);
  }
  if (anonRequest) await anonRequest.dispose();
  if (userRequest) await userRequest.dispose();
  if (adminRequest) await adminRequest.dispose();
});

const today = () => new Date().toISOString().slice(0, 10);
const range = () => ({ from: '2026-04-01', to: today() });

test.describe('Monitoring API — public access (Platform v11)', () => {
  test('admin: GET /api/monitoring/ai-summary returns full schema', async () => {
    const resp = await adminRequest.get('/api/monitoring/ai-summary', { params: range() });
    expect(resp.status()).toBe(200);
    const body = await resp.json() as any;
    expect(body.success).toBe(true);
    expect(body.data).toMatchObject({
      totalCalls: expect.any(Number),
      totalTokens: expect.any(Number),
      successCount: expect.any(Number),
      failureCount: expect.any(Number),
      byProvider: expect.any(Array),
      byFeature: expect.any(Array),
    });
    expect(body.data.totalCost).toBeDefined();
  });

  test('user (non-admin): GET /api/monitoring/ai-summary now allowed (path moved off /api/admin)', async () => {
    test.skip(userRequest === null, 'USER provisioning failed — skip role check');
    const resp = await userRequest!.get('/api/monitoring/ai-summary', { params: range() });
    expect(resp.status()).toBe(200);
  });

  test('anonymous: GET /api/monitoring/ai-summary returns 200 under demo mode', async () => {
    const resp = await anonRequest.get('/api/monitoring/ai-summary', { params: range() });
    expect(resp.status()).toBe(200);
    const body = await resp.json() as any;
    expect(body.success).toBe(true);
  });

  test('anonymous: GET /api/monitoring/ai-daily-trend returns array', async () => {
    const resp = await anonRequest.get('/api/monitoring/ai-daily-trend', { params: range() });
    expect(resp.status()).toBe(200);
    const body = await resp.json() as any;
    expect(Array.isArray(body.data)).toBe(true);
  });

  test('anonymous: GET /api/monitoring/ai-by-feature returns array of features', async () => {
    const resp = await anonRequest.get('/api/monitoring/ai-by-feature', { params: range() });
    expect(resp.status()).toBe(200);
    const body = await resp.json() as any;
    expect(Array.isArray(body.data)).toBe(true);
    if (body.data.length > 0) {
      expect(body.data[0]).toMatchObject({
        feature: expect.any(String),
        provider: expect.any(String),
        calls: expect.any(Number),
        cost: expect.anything(),
      });
    }
  });

  test('anonymous: GET /api/monitoring/api-summary returns endpoint counts', async () => {
    const resp = await anonRequest.get('/api/monitoring/api-summary', { params: range() });
    expect(resp.status()).toBe(200);
    const body = await resp.json() as any;
    expect(body.data).toMatchObject({
      totalRequests: expect.any(Number),
      byFeature: expect.any(Array),
      topEndpoints: expect.any(Array),
    });
  });

  test('anonymous: missing from param returns 4xx (validation error)', async () => {
    const resp = await anonRequest.get('/api/monitoring/ai-summary', {
      params: { to: today() },
    });
    expect(resp.status()).toBeGreaterThanOrEqual(400);
    expect(resp.status()).toBeLessThan(500);
  });

  test('anonymous: garbage date format returns 4xx', async () => {
    const resp = await anonRequest.get('/api/monitoring/ai-summary', {
      params: { from: 'banana', to: today() },
    });
    expect(resp.status()).toBeGreaterThanOrEqual(400);
    expect(resp.status()).toBeLessThan(500);
  });

  test('legacy /api/admin/monitoring path stays gone — anonymous, demo mode', async () => {
    // Even with demo-mode anonymous injection, the path itself was moved off
    // /api/admin/monitoring. SecurityConfig still gates /api/admin/** by ADMIN, so
    // anonymous request lands on 401/403/404 — never 200. This guards against a
    // future regression that re-mounts the controller back under /api/admin.
    const resp = await anonRequest.get('/api/admin/monitoring/ai-summary', { params: range() });
    expect(resp.status()).not.toBe(200);
    expect([401, 403, 404]).toContain(resp.status());
  });

  test('legacy /api/admin/monitoring path stays protected even for ADMIN (controller moved)', async () => {
    // ADMIN can authenticate but the handler is at /api/monitoring now — the
    // legacy URL must respond 404 (no handler) to make breakage loud.
    const resp = await adminRequest.get('/api/admin/monitoring/ai-summary', { params: range() });
    expect(resp.status()).toBe(404);
  });
});

test.describe('Monitoring API — login_required=true blocks anonymous', () => {
  test.beforeAll(async () => {
    await adminRequest.patch('/api/settings', { data: { loginRequired: true } });
  });

  test.afterAll(async () => {
    await adminRequest.patch('/api/settings', { data: { loginRequired: false } });
  });

  test('anonymous: GET /api/monitoring/ai-summary blocked when loginRequired=true', async () => {
    const resp = await anonRequest.get('/api/monitoring/ai-summary', { params: range() });
    expect([401, 403]).toContain(resp.status());
  });

  test('anonymous: GET /api/monitoring/ai-by-feature blocked when loginRequired=true', async () => {
    const resp = await anonRequest.get('/api/monitoring/ai-by-feature', { params: range() });
    expect([401, 403]).toContain(resp.status());
  });

  test('admin: GET /api/monitoring/ai-summary still 200 when loginRequired=true', async () => {
    const resp = await adminRequest.get('/api/monitoring/ai-summary', { params: range() });
    expect(resp.status()).toBe(200);
  });
});
