import { test, expect, APIRequestContext } from '@playwright/test';

/**
 * Platform v11 Step 5 — Monitoring page UI E2E.
 *
 * Validates:
 *   - Anonymous visitor (loginRequired=false) reaches /monitoring without
 *     redirecting to /login and sees the page header + date range controls.
 *   - The Monitoring NavLink in the layout sidebar is visible to anonymous
 *     visitors only when loginRequired=false (demo mode policy).
 *   - When loginRequired=true is restored, anonymous /monitoring is bounced
 *     to /login (regression guard for the demo-mode toggle).
 *
 * IMPORTANT: afterAll always restores loginRequired to its original value,
 * regardless of test outcome.
 */

const API_URL = process.env.API_URL || 'http://localhost:8080';

let adminRequest: APIRequestContext;
let originalLoginRequired = true;

test.beforeAll(async ({ playwright }) => {
  const base = await playwright.request.newContext({ baseURL: API_URL });
  const loginResp = await base.post('/api/auth/login', {
    data: { username: 'admin', password: 'admin' },
  });
  expect(loginResp.status()).toBe(200);
  const adminToken = (await loginResp.json() as any).data.token;
  await base.dispose();

  adminRequest = await playwright.request.newContext({
    baseURL: API_URL,
    extraHTTPHeaders: { Authorization: `Bearer ${adminToken}` },
  });

  // Snapshot + flip demo mode
  const settings = await adminRequest.get('/api/settings');
  originalLoginRequired = (await settings.json() as any).data.loginRequired;
  await adminRequest.patch('/api/settings', { data: { loginRequired: false } });
});

test.afterAll(async () => {
  try {
    if (adminRequest) {
      await adminRequest.patch('/api/settings', {
        data: { loginRequired: originalLoginRequired },
      });
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('monitoring.spec afterAll restore failed:', err);
  }
  if (adminRequest) await adminRequest.dispose();
});

test.describe('Monitoring page UI — demo-mode anonymous access', () => {
  test.beforeEach(async ({ page }) => {
    // Force logged-out state in the browser context
    await page.goto('/login');
    await page.evaluate(() => {
      localStorage.removeItem('my-atlas-token');
      localStorage.removeItem('my-atlas-user');
    });
  });

  test('anonymous visitor can navigate to /monitoring and see the page header', async ({ page }) => {
    await page.goto('/monitoring');

    // Must not be bounced to /login when loginRequired=false
    await expect(page).toHaveURL(/\/monitoring$/);
    await expect(page.getByRole('heading', { name: 'Monitoring', exact: true }))
        .toBeVisible({ timeout: 10000 });
  });

  test('Monitoring page renders date range inputs', async ({ page }) => {
    await page.goto('/monitoring');
    await expect(page.getByRole('heading', { name: 'Monitoring', exact: true })).toBeVisible();

    // Two <input type="date"> for from/to
    const dateInputs = page.locator('input[type="date"]');
    await expect(dateInputs).toHaveCount(2);
    await expect(dateInputs.nth(0)).toBeVisible();
    await expect(dateInputs.nth(1)).toBeVisible();
  });

  test('Monitoring page eventually settles (loading text disappears) without throwing', async ({ page }) => {
    await page.goto('/monitoring');

    // The "Loading monitoring data..." text appears while the initial API call is in flight.
    // It must clear once the response resolves — anything else means the page errored or
    // hung the React state machine.
    await expect(page.getByText('Loading monitoring data...')).toHaveCount(0, { timeout: 15000 });

    // No error banner from the page-level error boundary.
    await expect(page.locator('p.text-red-500')).toHaveCount(0);
  });

  test('Sidebar exposes Monitoring link to anonymous visitor under demo mode', async ({ page }) => {
    // Land on a route inside the Layout shell (not /login) so the sidebar renders.
    await page.goto('/');
    await expect(page.getByRole('link', { name: 'Monitoring' })).toBeVisible({ timeout: 10000 });
  });

  test('Clicking the sidebar Monitoring link routes to /monitoring', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('link', { name: 'Monitoring' }).click();
    await expect(page).toHaveURL(/\/monitoring$/);
    await expect(page.getByRole('heading', { name: 'Monitoring', exact: true })).toBeVisible();
  });
});

test.describe('Monitoring page UI — loginRequired=true regression guard', () => {
  test.beforeAll(async () => {
    await adminRequest.patch('/api/settings', { data: { loginRequired: true } });
  });

  test.afterAll(async () => {
    // Restore demo mode for the parent describe's afterAll baseline.
    await adminRequest.patch('/api/settings', { data: { loginRequired: false } });
  });

  test.beforeEach(async ({ page }) => {
    await page.goto('/login');
    await page.evaluate(() => {
      localStorage.removeItem('my-atlas-token');
      localStorage.removeItem('my-atlas-user');
    });
  });

  test('anonymous visitor is bounced to /login when loginRequired=true', async ({ page }) => {
    await page.goto('/monitoring');
    // ProtectedRoute should redirect when loginRequired===true and no token.
    await expect(page).toHaveURL(/\/login/, { timeout: 10000 });
  });
});
